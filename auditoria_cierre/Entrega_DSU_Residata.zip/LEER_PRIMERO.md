# Entrega local de DSU y Residata

El documento incluye trece capítulos. Los resultados y limitaciones están en 05_control/09_auditoria_final.md. No se ha publicado esta versión: el titular realizará la publicación. Las URLs/QR de Residata respondieron HTTP 200 en la reverificación, pero su contenido es anterior: la actualización local está pendiente de publicación.

01_documento: Word/PDF académico. 02_manuales: PAPS, SQAP y manual por rol extraídos. 03_pitch: propuesta financiera. 04_marketing: material diseñado, no campaña ejecutada. 05_control: matrices, guion y pendientes. 06_legal: borradores sin firmas ni registros ficticios. 07_pruebas: evidencias con su entorno. 08_codigo_fuente_sin_secretos.zip: código sin .env real ni historial Git.

Para reproducir el código: usar Python 3.12 en backend y Node >=22.22 en frontend; instalar las dependencias declaradas. Copiar .env.example a una configuración privada y proporcionar valores por canal seguro. El paquete NO contiene la conexión privada. No ejecutar seed ni pruebas con escritura sobre Neon compartido. Usar el runner aislado con PostgreSQL 18 local; navegador de pruebas requiere Playwright/Chrome. Docker/CI son otra opción descrita en el repositorio.

El respaldo privado del trabajo previo queda fuera de este paquete. No se incluyen dumps de base, perfiles personales ni credenciales. No se declara aceptación institucional, registro empresarial, ventas, facturación habilitada ni certificación de calidad.
